package com.project.services;

import java.sql.Date;
import java.util.List;
import java.util.Optional;

import com.project.entities.*;




public interface BookFlightService {
	public List<Flight> displayFlights();
	public Flight viewFlight(int flightNumber);
}
