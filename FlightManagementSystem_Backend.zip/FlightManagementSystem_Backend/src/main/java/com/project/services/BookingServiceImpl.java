package com.project.services;

import java.util.List;
//
import javax.transaction.Transactional;
//
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.Dao.*;
import com.project.entities.Booking;


@Transactional
@Service
public class BookingServiceImpl implements BookingService
{

	@Autowired
	private BookingDao bookingDao;

	
	
	@Override
	public Booking addBookingService(Booking booking) 
	{
		// TODO Auto-generated method stub
		bookingDao.addBooking(booking);
		return booking;
	}

	
	
	
	@Override
		public List<Booking> viewBooking() {
			// TODO Auto-generated method stub
			return bookingDao.viewBooking();
	}
	
	
	
	
	@Override
	public Booking cancelBookingService(long bookingId)
	{
		// TODO Auto-generated method stub
		return bookingDao.cancelBooking(bookingId);
	
	}




	@Override
	public List<Booking> viewBooking(long userId) {
		// TODO Auto-generated method stub
		return bookingDao.viewBooking(userId);	}

}
