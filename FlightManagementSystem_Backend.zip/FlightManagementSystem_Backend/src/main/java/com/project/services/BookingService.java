package com.project.services;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.project.entities.*;



@Repository
public interface BookingService {
	 Booking addBookingService(Booking  booking);
	
	List<Booking> viewBooking();
		
	 Booking cancelBookingService(long bookingId);
	
	List<Booking> viewBooking(long userId);
	
}
