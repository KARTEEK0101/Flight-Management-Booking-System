package com.project.Dao;
import java.math.BigInteger;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import org.springframework.stereotype.Repository;

import com.project.entities.*;



@Repository
public class BookingDaoImpl implements BookingDao{

	@PersistenceContext
	EntityManager entityManager;
	
	
	@Override
	public Booking addBooking(Booking bookingList) {
		// TODO Auto-generated method stub
		//entityManager.persist(bookingList);
		for (Passenger passenger : bookingList.getPassenger()) {
		    entityManager.persist(passenger);
		}
		// Now you can persist the Booking entity
		Booking booking = entityManager.merge(bookingList);
		
		return booking;
	}

	
	@Override
	public List<Booking> viewBooking() {
	// TODO Auto-generated method stub
		String Qstr = "SELECT booking FROM Booking booking WHERE booking.bookingId > 5000 ORDER BY booking.bookingId DESC";
		TypedQuery<Booking> query = entityManager.createQuery(Qstr, Booking.class);
		return query.getResultList();
}



	@Override
	public Booking cancelBooking(long bookingId) {
		// TODO Auto-generated method stub
		Booking cancelbooking = entityManager.find(Booking.class, bookingId);
		if(cancelbooking!=null)
			{
			entityManager.remove(cancelbooking);
			}
		return cancelbooking;
	}


	
	@Override
	public List<Booking> viewBooking(long userId) {
		// TODO Auto-generated method stub
		TypedQuery<Booking> query = entityManager.createQuery(
		        "SELECT b FROM Booking b WHERE b.userId = :userId AND b.userId!=0", Booking.class);
		    query.setParameter("userId", userId);
		    return query.getResultList();
		
	}
	
	
	
	
	
}


