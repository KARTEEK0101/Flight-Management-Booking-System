package com.project.Dao;

import java.util.List;

import com.project.entities.Airport;
import com.project.entities.Flight;
import com.project.entities.Schedule;
import com.project.entities.ScheduledFlight;
import com.project.entities.Search;
import com.project.entities.Users;

public interface ScheduleDao {

	public void add(Schedule schedule);

	public List<Object> viewAirportCode();

	public List<Object> viewAirportLoc();
	
	public List<Object> viewFlightNum();

	public List<Object> viewScheduleIds();

	public List<Schedule> viewAllSchedule();

	public void delete(int id);

	public void update(int id, Schedule schedule);

	public Schedule findById(int id);

	public List<Schedule> searchScheduledFlights(Search search);
	
//	public Users loginAdmin(String UserName,String password);

}
