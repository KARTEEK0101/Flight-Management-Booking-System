package com.project.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.entities.Schedule;
import com.project.entities.Users;

public interface LoginDao extends JpaRepository<Users, Long> {
	
	 
	   public Users findByEmail(String email);
	   
	

}
