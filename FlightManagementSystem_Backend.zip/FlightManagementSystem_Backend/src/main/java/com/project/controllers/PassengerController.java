package com.project.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.Dao.*;
import com.project.entities.*;
import com.project.exceptions.*;
import com.project.services.*;




@RestController
@CrossOrigin("http://localhost:4200")
public class PassengerController {
	
	 @Autowired
     PassengerService passengerservice;
	 @GetMapping("/getPassenger/{PnrNumber}")
	 public ResponseEntity<Passenger> getPassenger(@PathVariable long PnrNumber) {
	     Passenger passenger = passengerservice.viewPassenger(PnrNumber);
	     if (passenger != null) {
	         return new ResponseEntity<>(passenger, HttpStatus.OK);
	     } else {
	         return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	     }
	 }

	 @PostMapping(value = "/addPassenger", consumes = "application/json")
	 public ResponseEntity<String> addPassenger(@RequestBody Passenger passenger) {
	     Passenger addedPassenger = passengerservice.addPassenger(passenger);
	     if (addedPassenger != null) {
	         return new ResponseEntity<>("Passenger added successfully.", HttpStatus.CREATED);
	     } else {
	         return new ResponseEntity<>("Failed to add passenger.", HttpStatus.INTERNAL_SERVER_ERROR);
	     }
	 }

	 @GetMapping("/getAllPassenger")
	 public ResponseEntity<List<Passenger>> viewPassenger() {
	     List<Passenger> passengers = passengerservice.viewPassenger();
	     if (!passengers.isEmpty()) {
	         return new ResponseEntity<>(passengers, HttpStatus.OK);
	     } else {
	         return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	     }
	 }

	 @DeleteMapping("/deletePassenger/{bookingid}")
	 public ResponseEntity<String> deleteBooking(@PathVariable long bookingid) {
	         passengerservice.deletePassenger(bookingid);
	         return new ResponseEntity<>("Passenger deleted successfully.", HttpStatus.OK);
	 }

	 @PutMapping("/updatePassenger")
	 public ResponseEntity<Passenger> updateUser(@RequestBody Passenger p) {
	     Passenger updatedPassenger = passengerservice.modifyPassenger(p);
	     if (updatedPassenger != null) {
	         return new ResponseEntity<>(updatedPassenger, HttpStatus.OK);
	     } else {
	         return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	     }
	 }

}
