package com.project.controllers;


import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.Dao.LoginDao;
import com.project.entities.Users;
import com.project.exceptions.AirportException;
import com.project.exceptions.LoginException;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class LoginController {
	
	
	
	@Autowired
	private LoginDao logindao;
	

    @PostMapping("/register")
    public ResponseEntity<Users> register(@RequestBody Users newUser) {
        
        if (logindao.findByEmail(newUser.getEmail()) != null) {
        	
        	 throw new LoginException("User already exist");
            
        }

        else {
        	
        	Users result=logindao.save(newUser);
        	
            return new ResponseEntity<>(result,HttpStatus.OK) ;
        }
    }

    @PostMapping("/login")
    public ResponseEntity<Users> login(@RequestBody Map<String, String> credentials) {
        
    	String email = credentials.get("email");
        String password = credentials.get("password");
    	
    	Users user = logindao.findByEmail(email);
    	
        if (user != null && user.getPassword().equals(password)) {
        	
            return new ResponseEntity<>(user, HttpStatus.OK);
            
        } else {
            
             throw new LoginException("Please enter correct email and password. If you doesn't have account with us please register");
            
        }
    }
}



