package com.project.entities;

import java.io.Serializable;
import java.sql.Date;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Autowired;


	      

	       import java.io.Serializable;
	       import java.sql.Date;
	       import java.util.ArrayList;
	       import java.util.List;

	       import javax.persistence.CascadeType;
	       import javax.persistence.Column;
	       import javax.persistence.Entity;
	       import javax.persistence.FetchType;
	       import javax.persistence.GeneratedValue;
	       import javax.persistence.GenerationType;
	       import javax.persistence.Id;
	       import javax.persistence.JoinColumn;
	       import javax.persistence.JoinColumns;
	       import javax.persistence.ManyToOne;
	       import javax.persistence.OneToMany;
	       import javax.persistence.SequenceGenerator;
	       import javax.persistence.Table;
	       import javax.validation.Valid;
	       import javax.validation.constraints.Pattern;

	       import org.springframework.beans.factory.annotation.Autowired;

	       import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "Booking")
public class Booking implements Serializable {

	       	public Booking() {
	       		super();
	       		// TODO Auto-generated constructor stub
	       	}

	       	@Id
	       	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_seq")
	        @SequenceGenerator(name = "my_seq", sequenceName = "my_seq", allocationSize = 1)
	       	long  bookingId;
	       	
	       	
//	        @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_seq")
//	        @SequenceGenerator(name = "my_seq", sequenceName = "my_seq", allocationSize = 1)
//	        @Column(name = "pnr_number")
//	       	private long pnrNumber;
	          
	       	
	      	long userId;

	       	Date Bookingdate;
	       	
	       	@OneToMany(cascade = CascadeType.ALL)
	       	private List<Passenger> passenger;

	       	double ticketCost;

	       	String flightNumber; 
	       	
	       	int noOfPassengers;

	        @ElementCollection
	        @Column(name="seat_numbers")
	         public List<String> seatNumbers;
	          
	          int extraBaggage;
	           
	          
	          
	          @ManyToOne
	      	@JoinColumn(name = "SourceAirportCode", referencedColumnName = "AirportCode")
	      	public Airport sourceAirport;

	      	@ManyToOne
	      	@JoinColumn(name = "DestAirportCode", referencedColumnName = "AirportCode")
	      	public Airport destinationAirport;

	      	
	      	public LocalDateTime  ArrivalTime;
	      	 
	      	
	      	public LocalDateTime  DepartureTime;
	          
	          
	          
	     
	          

	       	public Booking(long bookingId, long userId, Date bookingdate, @Valid List<Passenger> passenger, double ticketCost,
	       			String flightNumber, int noOfPassengers, List<String> seatNumbers, int extraBaggage,Airport sourceAirport, Airport destinationAirport,LocalDateTime  ArrivalTime,
	    			LocalDateTime  DepartureTime ) {
	       		this.bookingId = bookingId;
	       		this.userId = userId;
	       		Bookingdate = bookingdate;
	       		this.passenger = passenger;
	       		this.ticketCost = ticketCost;
	       		this.flightNumber = flightNumber;
	       		this.noOfPassengers = noOfPassengers;
	       		this.seatNumbers = seatNumbers;
	       		this.extraBaggage = extraBaggage;
	       		
	       		
	       		//this.pnrNumber=pnrNumber;
	       		this.sourceAirport = sourceAirport;
	    		this.destinationAirport = destinationAirport;

	    		this.ArrivalTime = ArrivalTime;
	    		this.DepartureTime = DepartureTime;
	       		
	       		
	       	}

	       
      	
	       	
	       	public Airport getSourceAirport() {
	    		return sourceAirport;
	    	}

	    	public void setSourceAirport(Airport sourceAirport) {
	    		this.sourceAirport = sourceAirport;
	    	}

	    	public Airport getDestinationAirport() {
	    		return destinationAirport;
	    	}

	    	public void setDestinationAirport(Airport destinationAirport) {
	    		this.destinationAirport = destinationAirport;
	    		
	    		}
	    	
	    	public LocalDateTime  getArrivalTime() {
	    		return ArrivalTime;
	    	}

	    	public void setArrivalTime(LocalDateTime  arrivalTime) {
	    		this.ArrivalTime = arrivalTime;
	    	}

	    	public LocalDateTime  getDepartureTime() {
	    		return DepartureTime;
	    	}

	    	public void setDepartureTime(LocalDateTime  departureTime) {
	    		this.DepartureTime = departureTime;
	    	}

	       	
	       	
	       	
	       	
	       	
	       	
	       	public List<String> getSeatNumbers() {
	       		return seatNumbers;
	       	}

	       	public void setSeatType(List<String> seatNumbers) {
	       		this.seatNumbers = seatNumbers;
	       	}

	       	public int getExtraBaggage() {
	       		return extraBaggage;
	       	}

	       	public void setExtraBabbage(int extraBaggage) {
	       		this.extraBaggage = extraBaggage;
	       	}

	       	public String getFlightNumber() {
	       		return flightNumber;
	       	}

	       	public void setFlightNumber(String flightNumber) {
	       		this.flightNumber = flightNumber;
	       	}

	       	public Booking(long bookingId) {
	       		bookingId = bookingId;
	       	}

	       	public long getBookingId() {
	       		return bookingId;
	       	}

	       	public void setBookingId(long bookingId) {
	       		bookingId = bookingId;
	       	}


	       	public Date getBookingdate() {
	       		return Bookingdate;
	       	}

	       	public void setBookingdate(Date bookingdate) {
	       		Bookingdate = bookingdate;
	       	}

	       	public List<Passenger> getPassenger() {
	       		return passenger;
	       	}

	       	public void setPassenger(List<Passenger> passenger) {
	       		this.passenger = passenger;
	       	}

	       	public double getTicketCost() {
	       		return ticketCost;
	       	}

	       	public void setTicketCost(double ticketCost) {
	       		this.ticketCost = ticketCost;
	       	}

	       	
	       	
//	    	public long getPnrNumber() {
//	       		return pnrNumber;
//	       	}
//
//	       	public void setPnrNumber(long pnrNumber) {
//	       		this.pnrNumber = pnrNumber;
//	       	}

	       	
	        private String generateRandomPnr() {
	            UUID uuid = UUID.randomUUID();
	            // Extract a substring of the UUID to get a shorter PNR number
	            return uuid.toString().substring(0, 8).toUpperCase();
	        }
	       	
	       	
	       	



	       	public long getUserId() {
	       		return userId;
	       	}

	       	public void setUserId(long userId) {
	       		this.userId = userId;
	       	}


	       	public int getNoOfPassengers() {
	       		return noOfPassengers;
	       	}

	       	public void setNoOfPassengers(int noOfPassengers) {
	       		this.noOfPassengers = noOfPassengers;
	       	}

	       	
	       	/**
	       	 * 
	       	 * @param bookingId
	       	 * @param userId
	       	 * @param bookingdate
	       	 * @param passenger
	       	 * @param ticketCost
	       	 * @param flight
	       	 * @param noOfPassengers
	       	 */
	       	
	       }

	       