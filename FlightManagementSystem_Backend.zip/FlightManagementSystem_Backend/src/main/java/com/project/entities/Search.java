package com.project.entities;

import java.time.LocalDateTime;

import javax.persistence.Column;

public class Search {

	    
	    public Airport sourceAirport;
	    
	    @Column(length=25)
	    public LocalDateTime departureTime;
	    
	    public Airport destinationAirport;
	    
	    
		public Airport getSourceAirport() {
			return sourceAirport;
		}
		public void setSourceAirport(Airport sourceAirport) {
			this.sourceAirport = sourceAirport;
		}
		public LocalDateTime getDeparturTime() {
			return departureTime;
		}
		public void setDeparturTime(LocalDateTime departurTime) {
			departureTime = departurTime;
		}
		public Airport getDestinationAirport() {
			return destinationAirport;
		}
		public void setDestinationAirport(Airport destinationAirport) {
			this.destinationAirport = destinationAirport;
		}
	    
	    
}
