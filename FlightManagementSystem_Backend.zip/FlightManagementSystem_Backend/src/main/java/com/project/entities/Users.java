package com.project.entities;

import java.io.Serializable;
import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Autowired;

@Entity
@Table(name = "Users")
public class Users implements Serializable {


	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="user_id")  
	public int userId;
	
	@Column(length=10)
	public long userPhone;
	
    @Column(length=25)
	public String userType;
	
	@Column(length=25)
	public String password;
	
    
	public String email;
	
	
	 public Users() {
	        
	    }
	
	
	public Users(int userId, long userPhone,String userType,String password,String email) {
		
		this.userId=userId;
		this.userPhone=userPhone;
		this.userType=userType;
		this.password=password;
		this.email=email;
		
		
		
		
	}
	
	

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public long getUserPhone() {
		return userPhone;
	}

	public void setUserPhone(long userPhone) {
		this.userPhone = userPhone;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
