package com.project.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

@Entity
@Table(name="Passenger")
public class Passenger implements Serializable {
	
	
	               @Id
	               @GeneratedValue(strategy = GenerationType.AUTO)
	               public long passengerId;
	          
	          String passengerName;
	          
	          int passengerAge; 
	          
	          String gender;	  
			
			public Passenger(String passengerName, int passengerAge, String gender, long passengerId) {
				
				this.passengerName = passengerName;
				this.passengerAge = passengerAge;
				this.gender = gender;
				this.passengerId = passengerId;
			}
			
			public long getPassengerId() {
				return passengerId;
			}
			public void setPassengerId(long Id) {
				this.passengerId = passengerId;
			}
			public Passenger() {
				// TODO Auto-generated constructor stub
			}
			public String getGender() {
				return gender;
			}
			public void setGender(String gender) {
				this.gender = gender;
			}
//			public long getPnrNumber() {
//				return pnrNumber;
//			}
//			public void setPnrNumber(long pnrNumber) {
//				this.pnrNumber = pnrNumber;
//			}
			public String getPassengerName() {
				return passengerName;
			}
			public void setPassengerName(String passengerName) {
				this.passengerName = passengerName;
			}
			public int getPassengerAge() {
				return passengerAge;
			}
			public void setPassengerAge(int passengerAge) {
				this.passengerAge = passengerAge;
			}
			
	          
	          
	      

}
