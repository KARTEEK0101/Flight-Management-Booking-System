package com.project.exceptions;

public class AirportException extends RuntimeException{
	
	    
	private static final long serialVersionUID = 1L;

	public AirportException(String msg) {
		
		super(msg);
	}

}
